<template>
    <div>
        <section>
            <div class="container-fluid mt-5 mb-5 text-muted" style="line-height: 2.2;">
                <h3>Return Policy</h3>
                <p class="text-justify">
                    We have a friendly buyer protection policy! So please don’t worry in case of any wrong delivery. We are ready and bound to take back the goods you purchased only if we send any wrong size, color, selection, or manufacturing defects.
                </p>
                <h3>Refund Policy</h3>
                <p class="text-justify">
                    Sorry, currently we are not offering any refund, but in case of any out-of-stock of your issued goods, we refund only when the purchased goods are back within seven days to the same store in person as it was with hang-tag and poly packaging at the delivery time.
                    <br>
                    Please note that we give the refund money as a voucher by which you can pay us for your next purchase.
                </p>
            </div>
        </section>
    </div>
</template>
<script>

export default {
    data(){
        return{
            
        }
    }
}
</script>
<style>
    
</style>